
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Payment } from '@/types';
import { toast } from 'sonner';
import { useAuth } from './AuthContext';

interface PaymentContextType {
  payments: Payment[];
  userPayments: Payment[];
  isLoading: boolean;
  createPayment: (registrationId: string, amount: number) => Promise<Payment | null>;
  getPaymentsByUser: (userId: string) => Payment[];
  getPaymentsByRegistration: (registrationId: string) => Payment[];
  getPaymentById: (id: string) => Payment | undefined;
}

const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

// Mock payments for demo
const MOCK_PAYMENTS: Payment[] = [
  {
    id: '1',
    userId: '1',
    registrationId: '1',
    amount: 12000,
    status: 'completed',
    transactionId: 'txn_123456',
    paymentDate: '2023-05-16T15:30:00Z',
    paymentMethod: 'credit_card',
  },
  {
    id: '2',
    userId: '4',
    registrationId: '3',
    amount: 12000,
    status: 'completed',
    transactionId: 'txn_789012',
    paymentDate: '2023-05-15T16:45:00Z',
    paymentMethod: 'credit_card',
  },
];

export const PaymentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate fetching from an API
    const fetchPayments = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        setPayments(MOCK_PAYMENTS);
      } catch (error) {
        console.error('Failed to fetch payments:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPayments();
  }, []);

  // Filter payments for the current user
  const userPayments = currentUser
    ? payments.filter(payment => payment.userId === currentUser.id)
    : [];

  const createPayment = async (registrationId: string, amount: number): Promise<Payment | null> => {
    if (!currentUser) {
      toast.error('You must be logged in to make payments');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Simulate payment processing with a payment gateway
      const simulatePaymentGateway = async () => {
        await new Promise(resolve => setTimeout(resolve, 1000));
        return {
          success: true,
          transactionId: `txn_${Math.random().toString(36).substr(2, 6)}`,
        };
      };
      
      const paymentResult = await simulatePaymentGateway();
      
      if (paymentResult.success) {
        const newPayment: Payment = {
          id: String(Math.random().toString(36).substr(2, 9)),
          userId: currentUser.id,
          registrationId,
          amount,
          status: 'completed',
          transactionId: paymentResult.transactionId,
          paymentDate: new Date().toISOString(),
          paymentMethod: 'credit_card', // Simulated payment method
        };
        
        setPayments(prev => [...prev, newPayment]);
        toast.success('Payment processed successfully');
        return newPayment;
      } else {
        toast.error('Payment processing failed. Please try again.');
        return null;
      }
    } catch (error) {
      toast.error('Payment failed. Please try again later.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getPaymentsByUser = (userId: string): Payment[] => {
    return payments.filter(payment => payment.userId === userId);
  };

  const getPaymentsByRegistration = (registrationId: string): Payment[] => {
    return payments.filter(payment => payment.registrationId === registrationId);
  };

  const getPaymentById = (id: string): Payment | undefined => {
    return payments.find(payment => payment.id === id);
  };

  const value = {
    payments,
    userPayments,
    isLoading,
    createPayment,
    getPaymentsByUser,
    getPaymentsByRegistration,
    getPaymentById,
  };

  return <PaymentContext.Provider value={value}>{children}</PaymentContext.Provider>;
};

export const usePayments = () => {
  const context = useContext(PaymentContext);
  if (context === undefined) {
    throw new Error('usePayments must be used within a PaymentProvider');
  }
  return context;
};
