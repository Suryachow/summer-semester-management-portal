
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Report } from '@/types';
import { toast } from 'sonner';
import { useAuth } from './AuthContext';
import { useCourses } from './CourseContext';
import { useRegistrations } from './RegistrationContext';
import { useBacklogs } from './BacklogContext';
import { usePayments } from './PaymentContext';

interface ReportContextType {
  reports: Report[];
  isLoading: boolean;
  generateRegistrationReport: () => Promise<Report | null>;
  generateCompletionReport: () => Promise<Report | null>;
  generateBacklogReport: () => Promise<Report | null>;
  generatePaymentReport: () => Promise<Report | null>;
  getReportById: (id: string) => Report | undefined;
}

const ReportContext = createContext<ReportContextType | undefined>(undefined);

// Mock reports for demo
const MOCK_REPORTS: Report[] = [
  {
    id: '1',
    title: 'Summer Course Registration Summary',
    description: 'Summary of student registrations for summer courses',
    generatedBy: 'Admin User',
    generatedDate: '2023-05-18T10:30:00Z',
    type: 'registration',
    data: {
      totalRegistrations: 25,
      approvedRegistrations: 18,
      pendingRegistrations: 7,
      courseWiseRegistrations: [
        { courseName: 'Introduction to Computer Science', count: 12 },
        { courseName: 'Calculus II', count: 8 },
        { courseName: 'Physics for Engineers', count: 5 },
      ],
    },
  },
  {
    id: '2',
    title: 'Backlog Course Status',
    description: 'Status of student backlogs as of May 2023',
    generatedBy: 'Admin User',
    generatedDate: '2023-05-17T14:45:00Z',
    type: 'backlog',
    data: {
      totalBacklogs: 15,
      registeredBacklogs: 10,
      completedBacklogs: 3,
      pendingBacklogs: 2,
    },
  },
];

export const ReportProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const { courses } = useCourses();
  const { registrations } = useRegistrations();
  const { backlogs } = useBacklogs();
  const { payments } = usePayments();
  const [reports, setReports] = useState<Report[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate fetching from an API
    const fetchReports = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        setReports(MOCK_REPORTS);
      } catch (error) {
        console.error('Failed to fetch reports:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchReports();
  }, []);

  const generateRegistrationReport = async (): Promise<Report | null> => {
    if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'faculty')) {
      toast.error('You do not have permission to generate reports');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Process registration data
      const totalRegistrations = registrations.length;
      const approvedRegistrations = registrations.filter(reg => reg.status === 'approved').length;
      const pendingRegistrations = registrations.filter(reg => reg.status === 'pending').length;
      const rejectedRegistrations = registrations.filter(reg => reg.status === 'rejected').length;
      
      // Calculate course-wise registrations
      const courseWiseRegistrations = courses.map(course => ({
        courseId: course.id,
        courseName: course.name,
        count: registrations.filter(reg => reg.courseId === course.id).length,
      }));
      
      const newReport: Report = {
        id: String(Math.random().toString(36).substr(2, 9)),
        title: 'Course Registration Report',
        description: `Registration status report generated on ${new Date().toLocaleDateString()}`,
        generatedBy: currentUser.name,
        generatedDate: new Date().toISOString(),
        type: 'registration',
        data: {
          totalRegistrations,
          approvedRegistrations,
          pendingRegistrations,
          rejectedRegistrations,
          courseWiseRegistrations,
        },
      };
      
      setReports(prev => [newReport, ...prev]);
      toast.success('Registration report generated successfully');
      return newReport;
    } catch (error) {
      toast.error('Failed to generate report. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const generateCompletionReport = async (): Promise<Report | null> => {
    if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'faculty')) {
      toast.error('You do not have permission to generate reports');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Process course completion data (simplified demo implementation)
      const completedCourses = 8; // This would be calculated from real data
      const totalEnrollments = registrations.filter(reg => reg.status === 'approved').length;
      const completionRate = totalEnrollments > 0 ? (completedCourses / totalEnrollments) * 100 : 0;
      
      const newReport: Report = {
        id: String(Math.random().toString(36).substr(2, 9)),
        title: 'Course Completion Report',
        description: `Course completion report for summer semester generated on ${new Date().toLocaleDateString()}`,
        generatedBy: currentUser.name,
        generatedDate: new Date().toISOString(),
        type: 'completion',
        data: {
          totalEnrollments,
          completedCourses,
          incompleteCourses: totalEnrollments - completedCourses,
          completionRate: `${completionRate.toFixed(2)}%`,
          courseWiseCompletion: [
            { courseName: 'Introduction to Computer Science', completed: 4, total: 5 },
            { courseName: 'Calculus II', completed: 3, total: 4 },
            { courseName: 'Physics for Engineers', completed: 1, total: 3 },
          ],
        },
      };
      
      setReports(prev => [newReport, ...prev]);
      toast.success('Completion report generated successfully');
      return newReport;
    } catch (error) {
      toast.error('Failed to generate report. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const generateBacklogReport = async (): Promise<Report | null> => {
    if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'faculty')) {
      toast.error('You do not have permission to generate reports');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Process backlog data
      const totalBacklogs = backlogs.length;
      const pendingBacklogs = backlogs.filter(backlog => backlog.status === 'pending').length;
      const registeredBacklogs = backlogs.filter(backlog => backlog.status === 'registered').length;
      const completedBacklogs = backlogs.filter(backlog => backlog.status === 'completed').length;
      const failedBacklogs = backlogs.filter(backlog => backlog.status === 'failed').length;
      
      const newReport: Report = {
        id: String(Math.random().toString(36).substr(2, 9)),
        title: 'Backlog Course Report',
        description: `Backlog course status report generated on ${new Date().toLocaleDateString()}`,
        generatedBy: currentUser.name,
        generatedDate: new Date().toISOString(),
        type: 'backlog',
        data: {
          totalBacklogs,
          pendingBacklogs,
          registeredBacklogs,
          completedBacklogs,
          failedBacklogs,
          courseWiseBacklogs: [
            { courseName: 'Calculus II', count: 4 },
            { courseName: 'Technical Writing', count: 2 },
            { courseName: 'Database Systems', count: 3 },
          ],
        },
      };
      
      setReports(prev => [newReport, ...prev]);
      toast.success('Backlog report generated successfully');
      return newReport;
    } catch (error) {
      toast.error('Failed to generate report. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const generatePaymentReport = async (): Promise<Report | null> => {
    if (!currentUser || currentUser.role !== 'admin') {
      toast.error('You do not have permission to generate payment reports');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Process payment data
      const totalPayments = payments.length;
      const completedPayments = payments.filter(payment => payment.status === 'completed').length;
      const pendingPayments = payments.filter(payment => payment.status === 'pending').length;
      const failedPayments = payments.filter(payment => payment.status === 'failed').length;
      
      // Calculate total revenue
      const totalRevenue = payments
        .filter(payment => payment.status === 'completed')
        .reduce((sum, payment) => sum + payment.amount, 0);
      
      const newReport: Report = {
        id: String(Math.random().toString(36).substr(2, 9)),
        title: 'Payment Report',
        description: `Payment status report generated on ${new Date().toLocaleDateString()}`,
        generatedBy: currentUser.name,
        generatedDate: new Date().toISOString(),
        type: 'payment',
        data: {
          totalPayments,
          completedPayments,
          pendingPayments,
          failedPayments,
          totalRevenue,
          paymentMethods: {
            creditCard: payments.filter(payment => payment.paymentMethod === 'credit_card').length,
            bankTransfer: payments.filter(payment => payment.paymentMethod === 'bank_transfer').length,
            other: payments.filter(payment => 
              payment.paymentMethod !== 'credit_card' && payment.paymentMethod !== 'bank_transfer'
            ).length,
          },
        },
      };
      
      setReports(prev => [newReport, ...prev]);
      toast.success('Payment report generated successfully');
      return newReport;
    } catch (error) {
      toast.error('Failed to generate report. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getReportById = (id: string): Report | undefined => {
    return reports.find(report => report.id === id);
  };

  const value = {
    reports,
    isLoading,
    generateRegistrationReport,
    generateCompletionReport,
    generateBacklogReport,
    generatePaymentReport,
    getReportById,
  };

  return <ReportContext.Provider value={value}>{children}</ReportContext.Provider>;
};

export const useReports = () => {
  const context = useContext(ReportContext);
  if (context === undefined) {
    throw new Error('useReports must be used within a ReportProvider');
  }
  return context;
};
