
import React, { createContext, useContext, useState, useEffect } from 'react';
import { StudentBacklog } from '@/types';
import { toast } from 'sonner';
import { useAuth } from './AuthContext';

interface BacklogContextType {
  backlogs: StudentBacklog[];
  userBacklogs: StudentBacklog[];
  isLoading: boolean;
  addBacklog: (backlog: Omit<StudentBacklog, 'id'>) => Promise<StudentBacklog>;
  updateBacklogStatus: (id: string, status: StudentBacklog['status'], registrationId?: string) => Promise<StudentBacklog | null>;
  getBacklogById: (id: string) => StudentBacklog | undefined;
  getBacklogsByStudent: (studentId: string) => StudentBacklog[];
  getBacklogsByCourse: (courseId: string) => StudentBacklog[];
}

const BacklogContext = createContext<BacklogContextType | undefined>(undefined);

// Mock backlogs for demo
const MOCK_BACKLOGS: StudentBacklog[] = [
  {
    id: '1',
    studentId: '1',
    courseId: '2',
    courseName: 'Calculus II',
    semester: 'Spring 2023',
    academicYear: '2022-2023',
    status: 'registered',
    registrationId: '2',
  },
  {
    id: '2',
    studentId: '1',
    courseId: '4',
    courseName: 'Technical Writing',
    semester: 'Fall 2022',
    academicYear: '2022-2023',
    status: 'pending',
  },
  {
    id: '3',
    studentId: '4',
    courseId: '5',
    courseName: 'Database Systems',
    semester: 'Spring 2023',
    academicYear: '2022-2023',
    status: 'completed',
  },
];

export const BacklogProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [backlogs, setBacklogs] = useState<StudentBacklog[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate fetching from an API
    const fetchBacklogs = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        setBacklogs(MOCK_BACKLOGS);
      } catch (error) {
        console.error('Failed to fetch backlogs:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBacklogs();
  }, []);

  // Filter backlogs for the current user
  const userBacklogs = currentUser && currentUser.role === 'student'
    ? backlogs.filter(backlog => backlog.studentId === currentUser.id)
    : [];

  const addBacklog = async (backlogData: Omit<StudentBacklog, 'id'>): Promise<StudentBacklog> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newBacklog: StudentBacklog = {
        ...backlogData,
        id: String(Math.random().toString(36).substr(2, 9)),
      };
      
      setBacklogs(prev => [...prev, newBacklog]);
      toast.success('Backlog course added successfully');
      return newBacklog;
    } catch (error) {
      toast.error('Failed to add backlog course. Please try again.');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const updateBacklogStatus = async (
    id: string, 
    status: StudentBacklog['status'], 
    registrationId?: string
  ): Promise<StudentBacklog | null> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      let updatedBacklog: StudentBacklog | null = null;
      
      setBacklogs(prev => 
        prev.map(backlog => {
          if (backlog.id === id) {
            updatedBacklog = { 
              ...backlog, 
              status,
              registrationId: registrationId || backlog.registrationId,
            };
            return updatedBacklog;
          }
          return backlog;
        })
      );
      
      if (updatedBacklog) {
        toast.success(`Backlog status updated to ${status}`);
        return updatedBacklog;
      } else {
        toast.error('Backlog not found');
        return null;
      }
    } catch (error) {
      toast.error('Failed to update backlog status. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getBacklogById = (id: string): StudentBacklog | undefined => {
    return backlogs.find(backlog => backlog.id === id);
  };

  const getBacklogsByStudent = (studentId: string): StudentBacklog[] => {
    return backlogs.filter(backlog => backlog.studentId === studentId);
  };

  const getBacklogsByCourse = (courseId: string): StudentBacklog[] => {
    return backlogs.filter(backlog => backlog.courseId === courseId);
  };

  const value = {
    backlogs,
    userBacklogs,
    isLoading,
    addBacklog,
    updateBacklogStatus,
    getBacklogById,
    getBacklogsByStudent,
    getBacklogsByCourse,
  };

  return <BacklogContext.Provider value={value}>{children}</BacklogContext.Provider>;
};

export const useBacklogs = () => {
  const context = useContext(BacklogContext);
  if (context === undefined) {
    throw new Error('useBacklogs must be used within a BacklogProvider');
  }
  return context;
};
