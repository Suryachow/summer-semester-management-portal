
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Registration } from '@/types';
import { toast } from 'sonner';
import { useAuth } from './AuthContext';

interface RegistrationContextType {
  registrations: Registration[];
  userRegistrations: Registration[];
  isLoading: boolean;
  createRegistration: (courseId: string, courseName: string) => Promise<Registration | null>;
  updateRegistrationStatus: (id: string, status: 'approved' | 'rejected', comment?: string) => Promise<Registration | null>;
  updatePaymentStatus: (id: string, paymentId: string) => Promise<Registration | null>;
  getRegistrationById: (id: string) => Registration | undefined;
  getRegistrationsByCourse: (courseId: string) => Registration[];
  getRegistrationsByStudent: (studentId: string) => Registration[];
  cancelRegistration: (id: string) => Promise<boolean>;
}

const RegistrationContext = createContext<RegistrationContextType | undefined>(undefined);

// Mock registrations for demo
const MOCK_REGISTRATIONS: Registration[] = [
  {
    id: '1',
    studentId: '1',
    studentName: 'John Student',
    courseId: '1',
    courseName: 'Introduction to Computer Science',
    registrationDate: '2023-05-15T10:30:00Z',
    status: 'approved',
    paymentStatus: 'completed',
    paymentId: 'pay_123456',
    approvedBy: 'Jane Faculty',
    approvalDate: '2023-05-16T14:20:00Z',
  },
  {
    id: '2',
    studentId: '1',
    studentName: 'John Student',
    courseId: '2',
    courseName: 'Calculus II',
    registrationDate: '2023-05-16T11:45:00Z',
    status: 'pending',
    paymentStatus: 'pending',
  },
  {
    id: '3',
    studentId: '4',
    studentName: 'Alice Johnson',
    courseId: '1',
    courseName: 'Introduction to Computer Science',
    registrationDate: '2023-05-14T09:15:00Z',
    status: 'approved',
    paymentStatus: 'completed',
    paymentId: 'pay_789012',
    approvedBy: 'Jane Faculty',
    approvalDate: '2023-05-15T16:10:00Z',
  },
];

export const RegistrationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate fetching from an API
    const fetchRegistrations = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        setRegistrations(MOCK_REGISTRATIONS);
      } catch (error) {
        toast.error('Failed to load registrations. Please refresh the page.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchRegistrations();
  }, []);

  // Filter registrations for the current user
  const userRegistrations = currentUser 
    ? registrations.filter(reg => 
        currentUser.role === 'student' 
          ? reg.studentId === currentUser.id 
          : true
      )
    : [];

  const createRegistration = async (courseId: string, courseName: string): Promise<Registration | null> => {
    if (!currentUser) {
      toast.error('You must be logged in to register for courses.');
      return null;
    }

    if (currentUser.role !== 'student') {
      toast.error('Only students can register for courses.');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Check if already registered
      const existingRegistration = registrations.find(
        reg => reg.studentId === currentUser.id && reg.courseId === courseId
      );
      
      if (existingRegistration) {
        toast.error('You are already registered for this course.');
        return null;
      }
      
      const newRegistration: Registration = {
        id: String(Math.random().toString(36).substr(2, 9)),
        studentId: currentUser.id,
        studentName: currentUser.name,
        courseId,
        courseName,
        registrationDate: new Date().toISOString(),
        status: 'pending',
        paymentStatus: 'pending',
      };
      
      setRegistrations(prev => [...prev, newRegistration]);
      toast.success('Course registration submitted successfully!');
      return newRegistration;
    } catch (error) {
      toast.error('Failed to submit registration. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const updateRegistrationStatus = async (
    id: string, 
    status: 'approved' | 'rejected', 
    comment?: string
  ): Promise<Registration | null> => {
    if (!currentUser) {
      toast.error('You must be logged in to update registrations.');
      return null;
    }

    if (currentUser.role !== 'faculty' && currentUser.role !== 'admin') {
      toast.error('You do not have permission to update registration status.');
      return null;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      let updatedRegistration: Registration | null = null;
      
      setRegistrations(prev => 
        prev.map(reg => {
          if (reg.id === id) {
            updatedRegistration = {
              ...reg,
              status,
              approvedBy: currentUser.name,
              approvalDate: new Date().toISOString(),
              rejectionReason: status === 'rejected' ? comment : undefined,
            };
            return updatedRegistration;
          }
          return reg;
        })
      );
      
      if (updatedRegistration) {
        toast.success(`Registration ${status === 'approved' ? 'approved' : 'rejected'} successfully.`);
        return updatedRegistration;
      } else {
        toast.error('Registration not found.');
        return null;
      }
    } catch (error) {
      toast.error('Failed to update registration status. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const updatePaymentStatus = async (id: string, paymentId: string): Promise<Registration | null> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      let updatedRegistration: Registration | null = null;
      
      setRegistrations(prev => 
        prev.map(reg => {
          if (reg.id === id) {
            updatedRegistration = {
              ...reg,
              paymentStatus: 'completed',
              paymentId,
            };
            return updatedRegistration;
          }
          return reg;
        })
      );
      
      if (updatedRegistration) {
        toast.success('Payment completed successfully.');
        return updatedRegistration;
      } else {
        toast.error('Registration not found.');
        return null;
      }
    } catch (error) {
      toast.error('Failed to update payment status. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getRegistrationById = (id: string): Registration | undefined => {
    return registrations.find(reg => reg.id === id);
  };

  const getRegistrationsByCourse = (courseId: string): Registration[] => {
    return registrations.filter(reg => reg.courseId === courseId);
  };

  const getRegistrationsByStudent = (studentId: string): Registration[] => {
    return registrations.filter(reg => reg.studentId === studentId);
  };

  const cancelRegistration = async (id: string): Promise<boolean> => {
    if (!currentUser) {
      toast.error('You must be logged in to cancel registrations.');
      return false;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const registration = registrations.find(reg => reg.id === id);
      
      if (!registration) {
        toast.error('Registration not found.');
        return false;
      }
      
      if (currentUser.role === 'student' && registration.studentId !== currentUser.id) {
        toast.error('You can only cancel your own registrations.');
        return false;
      }
      
      if (registration.status === 'approved' && registration.paymentStatus === 'completed') {
        toast.error('Cannot cancel a paid and approved registration. Please contact administration.');
        return false;
      }
      
      setRegistrations(prev => prev.filter(reg => reg.id !== id));
      toast.success('Registration cancelled successfully.');
      return true;
    } catch (error) {
      toast.error('Failed to cancel registration. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    registrations,
    userRegistrations,
    isLoading,
    createRegistration,
    updateRegistrationStatus,
    updatePaymentStatus,
    getRegistrationById,
    getRegistrationsByCourse,
    getRegistrationsByStudent,
    cancelRegistration,
  };

  return <RegistrationContext.Provider value={value}>{children}</RegistrationContext.Provider>;
};

export const useRegistrations = () => {
  const context = useContext(RegistrationContext);
  if (context === undefined) {
    throw new Error('useRegistrations must be used within a RegistrationProvider');
  }
  return context;
};
