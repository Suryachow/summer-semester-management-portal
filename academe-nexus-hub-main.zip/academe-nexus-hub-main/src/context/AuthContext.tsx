
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '@/types';
import { toast } from 'sonner';

interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string, role: UserRole) => Promise<boolean>;
  logout: () => void;
  forgotPassword: (email: string) => Promise<boolean>;
  resetPassword: (token: string, newPassword: string) => Promise<boolean>;
  verifyOtp: (email: string, otp: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Updated mock user database with consistent data
const MOCK_USERS: User[] = [
  {
    id: '1',
    email: 'student@example.com',
    name: 'John Student',
    role: 'student',
    profileImage: '/placeholder.svg',
    status: 'Active',
    lastActive: '2023-06-15',
    department: 'Computer Science',
    joinedDate: '2021-07-10',
    cgpa: 3.75
  },
  {
    id: '2',
    email: 'faculty@example.com',
    name: 'Jane Faculty',
    role: 'faculty',
    profileImage: '/placeholder.svg',
    status: 'Active',
    lastActive: '2023-06-14',
    department: 'Computer Science',
    joinedDate: '2019-08-15'
  },
  {
    id: '3',
    email: 'admin@example.com',
    name: 'Admin User',
    role: 'admin',
    profileImage: '/placeholder.svg',
    status: 'Active',
    lastActive: '2023-06-16',
    department: 'Administration',
    joinedDate: '2018-01-20'
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Check for saved user in localStorage (simulating persistence)
    const savedUser = localStorage.getItem('academe_user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo, find user by email (in real app, would verify password)
      const user = MOCK_USERS.find(u => u.email === email);
      
      if (user) {
        // Update currentUser with ALL user data
        setCurrentUser({...user});
        localStorage.setItem('academe_user', JSON.stringify(user));
        toast.success(`Welcome back, ${user.name}!`);
        return true;
      } else {
        toast.error('Invalid credentials. Please try again.');
        return false;
      }
    } catch (error) {
      toast.error('Login failed. Please try again later.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (
    email: string, 
    password: string, 
    name: string, 
    role: UserRole
  ): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user already exists
      if (MOCK_USERS.some(u => u.email === email)) {
        toast.error('User with this email already exists.');
        return false;
      }
      
      // Create new user with all required fields
      const newUser: User = {
        id: String(MOCK_USERS.length + 1),
        email,
        name,
        role,
        profileImage: '/placeholder.svg',
        status: 'Active',
        lastActive: new Date().toISOString().split('T')[0],
        department: role === 'student' ? 'Computer Science' : 
                   role === 'faculty' ? 'Computer Science' : 'Administration',
        joinedDate: new Date().toISOString().split('T')[0],
        cgpa: role === 'student' ? 3.0 : undefined
      };
      
      // For demo, we'll add to our mock users array
      MOCK_USERS.push(newUser);
      
      // Log in the new user
      setCurrentUser(newUser);
      localStorage.setItem('academe_user', JSON.stringify(newUser));
      toast.success('Account created successfully!');
      return true;
    } catch (error) {
      toast.error('Signup failed. Please try again later.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('academe_user');
    toast.success('You have been logged out.');
  };

  const forgotPassword = async (email: string): Promise<boolean> => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user exists
      const user = MOCK_USERS.find(u => u.email === email);
      if (!user) {
        toast.error('No account found with this email.');
        return false;
      }
      
      // In a real application, send an email with a password reset link or OTP
      toast.success('Password reset instructions sent to your email.');
      return true;
    } catch (error) {
      toast.error('Failed to process request. Please try again later.');
      return false;
    }
  };

  const resetPassword = async (token: string, newPassword: string): Promise<boolean> => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real application, verify token and update password in database
      toast.success('Password reset successfully. Please log in with your new password.');
      return true;
    } catch (error) {
      toast.error('Failed to reset password. Please try again later.');
      return false;
    }
  };

  const verifyOtp = async (email: string, otp: string): Promise<boolean> => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo purposes, any 6-digit OTP works
      if (otp.length === 6 && /^\d+$/.test(otp)) {
        toast.success('OTP verified successfully.');
        return true;
      } else {
        toast.error('Invalid OTP. Please try again.');
        return false;
      }
    } catch (error) {
      toast.error('Failed to verify OTP. Please try again later.');
      return false;
    }
  };

  const value = {
    currentUser,
    isLoading,
    login,
    signup,
    logout,
    forgotPassword,
    resetPassword,
    verifyOtp,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
