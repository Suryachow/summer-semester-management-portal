
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Notification } from '@/types';
import { toast } from 'sonner';
import { useAuth } from './AuthContext';

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  isLoading: boolean;
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt' | 'isRead'>) => Promise<Notification>;
  markAsRead: (id: string) => Promise<boolean>;
  markAllAsRead: () => Promise<boolean>;
  deleteNotification: (id: string) => Promise<boolean>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// Mock notifications for demo
const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    userId: '1',
    title: 'Registration Approved',
    message: 'Your registration for Introduction to Computer Science has been approved.',
    createdAt: '2023-05-16T14:30:00Z',
    isRead: false,
    type: 'approval',
    link: '/courses/1',
  },
  {
    id: '2',
    userId: '1',
    title: 'Payment Reminder',
    message: 'Please complete your payment for Calculus II by May 20, 2023.',
    createdAt: '2023-05-17T10:15:00Z',
    isRead: true,
    type: 'payment',
    link: '/courses/2',
  },
  {
    id: '3',
    userId: '1',
    title: 'New Summer Course Available',
    message: 'A new course "Web Development with React" is now available for summer registration.',
    createdAt: '2023-05-18T09:45:00Z',
    isRead: false,
    type: 'general',
    link: '/courses',
  },
];

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate fetching from an API
    const fetchNotifications = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (currentUser) {
          // Filter notifications for the current user
          const userNotifications = MOCK_NOTIFICATIONS.filter(
            notification => notification.userId === currentUser.id
          );
          setNotifications(userNotifications);
        } else {
          setNotifications([]);
        }
      } catch (error) {
        console.error('Failed to fetch notifications:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchNotifications();
  }, [currentUser]);

  const unreadCount = notifications.filter(notification => !notification.isRead).length;

  const addNotification = async (
    notificationData: Omit<Notification, 'id' | 'createdAt' | 'isRead'>
  ): Promise<Notification> => {
    try {
      const newNotification: Notification = {
        ...notificationData,
        id: String(Math.random().toString(36).substr(2, 9)),
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      
      setNotifications(prev => [newNotification, ...prev]);
      return newNotification;
    } catch (error) {
      console.error('Failed to add notification:', error);
      throw error;
    }
  };

  const markAsRead = async (id: string): Promise<boolean> => {
    try {
      setNotifications(prev => 
        prev.map(notification => 
          notification.id === id 
            ? { ...notification, isRead: true } 
            : notification
        )
      );
      return true;
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
      return false;
    }
  };

  const markAllAsRead = async (): Promise<boolean> => {
    try {
      setNotifications(prev => 
        prev.map(notification => ({ ...notification, isRead: true }))
      );
      return true;
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
      return false;
    }
  };

  const deleteNotification = async (id: string): Promise<boolean> => {
    try {
      setNotifications(prev => prev.filter(notification => notification.id !== id));
      return true;
    } catch (error) {
      console.error('Failed to delete notification:', error);
      return false;
    }
  };

  const value = {
    notifications,
    unreadCount,
    isLoading,
    addNotification,
    markAsRead,
    markAllAsRead,
    deleteNotification,
  };

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
