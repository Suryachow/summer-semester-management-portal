
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Download, Filter, BarChart3, PieChart as PieChartIcon, LineChart, Calendar } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Reports = () => {
  const { toast } = useToast();
  const [period, setPeriod] = useState<string>('semester');

  // Mock data for registration statistics
  const registrationData = [
    { name: 'Week 1', Regular: 45, Backlog: 22 },
    { name: 'Week 2', Regular: 67, Backlog: 30 },
    { name: 'Week 3', Regular: 83, Backlog: 28 },
    { name: 'Week 4', Regular: 53, Backlog: 25 },
    { name: 'Week 5', Regular: 40, Backlog: 18 },
    { name: 'Week 6', Regular: 32, Backlog: 15 },
  ];

  // Mock data for course popularity
  const coursePopularityData = [
    { name: 'Database Management', value: 78 },
    { name: 'Machine Learning', value: 65 },
    { name: 'Digital Electronics', value: 45 },
    { name: 'Engineering Mechanics', value: 40 },
    { name: 'Data Structures', value: 35 },
  ];

  // Colors for pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  // Mock data for department statistics
  const departmentData = [
    { name: 'Computer Science', Regular: 120, Backlog: 45 },
    { name: 'Electrical Eng.', Regular: 80, Backlog: 35 },
    { name: 'Mechanical Eng.', Regular: 65, Backlog: 30 },
    { name: 'Civil Eng.', Regular: 50, Backlog: 25 },
    { name: 'Chemical Eng.', Regular: 40, Backlog: 20 },
  ];

  // Mock data for completion rates
  const completionData = [
    { course: 'Database Management', enrolled: 78, completed: 62, rate: 79 },
    { course: 'Machine Learning', enrolled: 65, completed: 45, rate: 69 },
    { course: 'Digital Electronics', enrolled: 45, completed: 38, rate: 84 },
    { course: 'Engineering Mechanics', enrolled: 40, completed: 32, rate: 80 },
    { course: 'Data Structures', enrolled: 35, completed: 28, rate: 80 },
  ];

  const handleDownloadReport = (reportType: string) => {
    toast({
      title: "Report download started",
      description: `${reportType} report is being generated and will download shortly.`,
    });
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-brand-800">Analytics & Reports</h1>
        
        <div className="flex gap-4">
          <Select
            value={period}
            onValueChange={setPeriod}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Current Week</SelectItem>
              <SelectItem value="month">Current Month</SelectItem>
              <SelectItem value="semester">Current Semester</SelectItem>
              <SelectItem value="year">Current Year</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Custom Date Range
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Registrations</CardTitle>
            <CardDescription>Current semester total</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">523</div>
            <div className="text-sm text-green-600 flex items-center mt-1">
              <span className="mr-1">↑</span> 12.5% from last semester
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Completion Rate</CardTitle>
            <CardDescription>Average across all courses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">78%</div>
            <Progress value={78} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Backlog Clearance</CardTitle>
            <CardDescription>Success rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">65%</div>
            <Progress value={65} className="mt-2" />
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="registrations" className="space-y-6">
        <TabsList className="grid grid-cols-4 w-full max-w-2xl mx-auto">
          <TabsTrigger value="registrations" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Registration Trends</span>
            <span className="sm:hidden">Registrations</span>
          </TabsTrigger>
          <TabsTrigger value="courses" className="flex items-center gap-2">
            <PieChartIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Course Popularity</span>
            <span className="sm:hidden">Courses</span>
          </TabsTrigger>
          <TabsTrigger value="departments" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Department Stats</span>
            <span className="sm:hidden">Departments</span>
          </TabsTrigger>
          <TabsTrigger value="completion" className="flex items-center gap-2">
            <LineChart className="h-4 w-4" />
            <span className="hidden sm:inline">Completion Rates</span>
            <span className="sm:hidden">Completion</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="registrations">
          <Card>
            <CardHeader>
              <CardTitle>Registration Trends</CardTitle>
              <CardDescription>
                Weekly registration counts for regular and backlog courses
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={registrationData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="Regular" stackId="1" stroke="#1a71f7" fill="#1a71f7" />
                  <Area type="monotone" dataKey="Backlog" stackId="1" stroke="#e6ae00" fill="#e6ae00" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => handleDownloadReport('Registration Trends')}
              >
                <Download className="h-4 w-4" />
                Download Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="courses">
          <Card>
            <CardHeader>
              <CardTitle>Course Popularity</CardTitle>
              <CardDescription>
                Distribution of student registrations across top courses
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col md:flex-row gap-6">
              <div className="w-full md:w-1/2 h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={coursePopularityData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {coursePopularityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              <div className="w-full md:w-1/2">
                <h3 className="text-lg font-medium mb-4">Top Courses by Registration</h3>
                <div className="space-y-4">
                  {coursePopularityData.map((course, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">{course.name}</span>
                        <span className="text-sm font-medium">{course.value} students</span>
                      </div>
                      <Progress value={(course.value / Math.max(...coursePopularityData.map(c => c.value))) * 100} 
                        className="h-2" 
                        style={{ backgroundColor: COLORS[index % COLORS.length] + '40' }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => handleDownloadReport('Course Popularity')}
              >
                <Download className="h-4 w-4" />
                Download Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="departments">
          <Card>
            <CardHeader>
              <CardTitle>Department Statistics</CardTitle>
              <CardDescription>
                Registration distribution across academic departments
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={departmentData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Regular" stackId="a" fill="#1a71f7" />
                  <Bar dataKey="Backlog" stackId="a" fill="#e6ae00" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => handleDownloadReport('Department Statistics')}
              >
                <Download className="h-4 w-4" />
                Download Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="completion">
          <Card>
            <CardHeader>
              <CardTitle>Course Completion Rates</CardTitle>
              <CardDescription>
                Student success rates across different courses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course</TableHead>
                    <TableHead className="text-center">Enrolled</TableHead>
                    <TableHead className="text-center">Completed</TableHead>
                    <TableHead className="text-right">Completion Rate</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {completionData.map((course, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{course.course}</TableCell>
                      <TableCell className="text-center">{course.enrolled}</TableCell>
                      <TableCell className="text-center">{course.completed}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Progress value={course.rate} className="w-20 h-2" />
                          <span>{course.rate}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => handleDownloadReport('Completion Rates')}
              >
                <Download className="h-4 w-4" />
                Download Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;
