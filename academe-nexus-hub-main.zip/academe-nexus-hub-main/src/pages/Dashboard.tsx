
import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { useCourses } from '@/context/CourseContext';
import { useRegistrations } from '@/context/RegistrationContext';
import { useBacklogs } from '@/context/BacklogContext';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { 
  BarChart,
  BookOpen,
  CheckCircle2,
  FileText,
  Users
} from 'lucide-react';

// Import the Area chart component from recharts
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis,
} from "recharts";

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { summerCourses, backlogCourses } = useCourses();
  const { registrations, userRegistrations } = useRegistrations();
  const { userBacklogs } = useBacklogs();

  // Check if the user is authenticated
  if (!currentUser) {
    return null;
  }

  // Sample chart data - in a real app this would come from actual data
  const chartData = [
    { name: "Jan", value: 0 },
    { name: "Feb", value: 12 },
    { name: "Mar", value: 26 },
    { name: "Apr", value: 40 },
    { name: "May", value: 78 },
    { name: "Jun", value: 95 },
    { name: "Jul", value: 82 },
    { name: "Aug", value: 60 },
    { name: "Sep", value: 42 },
    { name: "Oct", value: 30 },
    { name: "Nov", value: 15 },
    { name: "Dec", value: 8 },
  ];

  // Render content based on user role
  const renderStudentDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Available Summer Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summerCourses.length}</div>
            <div className="mt-4">
              <Button asChild variant="outline" size="sm">
                <Link to="/courses">View Courses</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">My Registrations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userRegistrations.length}</div>
            <div className="mt-4">
              <Button asChild variant="outline" size="sm">
                <Link to="/registrations">View Registrations</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">My Backlogs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userBacklogs.length}</div>
            <div className="mt-4">
              <Button asChild variant="outline" size="sm">
                <Link to="/backlogs">View Backlogs</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pending Payments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {userRegistrations.filter(reg => reg.paymentStatus === 'pending').length}
            </div>
            <div className="mt-4">
              <Button asChild variant="outline" size="sm">
                <Link to="/payments">View Payments</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Registration Status</CardTitle>
            <CardDescription>Your course registration status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {userRegistrations.length > 0 ? (
                userRegistrations.map((reg) => (
                  <div key={reg.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                    <div>
                      <div className="font-medium">{reg.courseName}</div>
                      <div className="text-sm text-gray-500">
                        Registered on {new Date(reg.registrationDate).toLocaleDateString()}
                      </div>
                    </div>
                    <div>
                      <span className={`
                        ${reg.status === 'pending' ? 'badge-status-pending' : ''}
                        ${reg.status === 'approved' ? 'badge-status-approved' : ''}
                        ${reg.status === 'rejected' ? 'badge-status-rejected' : ''}
                      `}>
                        {reg.status}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-12 h-12 mx-auto text-gray-300" />
                  <p className="mt-2">No registrations yet</p>
                  <Button asChild variant="outline" size="sm" className="mt-4">
                    <Link to="/courses">Browse Courses</Link>
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Activity Overview</CardTitle>
            <CardDescription>Your registration activity over time</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <RechartsTooltip />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#3b95ff"
                    fill="#3b95ff"
                    fillOpacity={0.2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderFacultyDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Summer Courses</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <BookOpen className="h-8 w-8 text-blue-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">{summerCourses.length}</div>
              <div className="mt-1 text-xs text-gray-500">Available for summer</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <FileText className="h-8 w-8 text-yellow-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">
                {registrations.filter(reg => reg.status === 'pending').length}
              </div>
              <div className="mt-1 text-xs text-gray-500">Need your approval</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Enrolled Students</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <Users className="h-8 w-8 text-green-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">
                {registrations.filter(reg => reg.status === 'approved').length}
              </div>
              <div className="mt-1 text-xs text-gray-500">Registered in your courses</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Backlog Courses</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <CheckCircle2 className="h-8 w-8 text-purple-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">{backlogCourses.length}</div>
              <div className="mt-1 text-xs text-gray-500">Available for backlog students</div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Pending Approvals</CardTitle>
            <CardDescription>Students awaiting your approval</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {registrations.filter(reg => reg.status === 'pending').length > 0 ? (
                registrations
                  .filter(reg => reg.status === 'pending')
                  .slice(0, 5)
                  .map((reg) => (
                    <div key={reg.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                      <div>
                        <div className="font-medium">{reg.studentName}</div>
                        <div className="text-sm text-gray-500">{reg.courseName}</div>
                      </div>
                      <Button asChild size="sm">
                        <Link to={`/registrations/${reg.id}`}>Review</Link>
                      </Button>
                    </div>
                  ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <CheckCircle2 className="w-12 h-12 mx-auto text-gray-300" />
                  <p className="mt-2">No pending approvals</p>
                </div>
              )}
              
              {registrations.filter(reg => reg.status === 'pending').length > 5 && (
                <div className="text-center mt-4">
                  <Button asChild variant="outline">
                    <Link to="/registrations">View All</Link>
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Registration Trends</CardTitle>
            <CardDescription>Course registration activity over time</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <RechartsTooltip />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#3b95ff"
                    fill="#3b95ff"
                    fillOpacity={0.2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderAdminDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total Courses</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <BookOpen className="h-8 w-8 text-blue-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">{summerCourses.length + backlogCourses.length}</div>
              <div className="mt-1 text-xs text-gray-500">Available courses</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total Registrations</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <FileText className="h-8 w-8 text-yellow-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">{registrations.length}</div>
              <div className="mt-1 text-xs text-gray-500">Course registrations</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <CheckCircle2 className="h-8 w-8 text-orange-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">
                {registrations.filter(reg => reg.status === 'pending').length}
              </div>
              <div className="mt-1 text-xs text-gray-500">Awaiting approval</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pending Payments</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <BarChart className="h-8 w-8 text-green-600 mr-4" />
            <div>
              <div className="text-2xl font-bold">
                {registrations.filter(reg => reg.paymentStatus === 'pending').length}
              </div>
              <div className="mt-1 text-xs text-gray-500">Payment pending</div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Registration Overview</CardTitle>
            <CardDescription>Summary of registration status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-lg font-bold text-green-700">
                    {registrations.filter(reg => reg.status === 'approved').length}
                  </div>
                  <div className="text-xs text-green-600">Approved</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                  <div className="text-lg font-bold text-yellow-700">
                    {registrations.filter(reg => reg.status === 'pending').length}
                  </div>
                  <div className="text-xs text-yellow-600">Pending</div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                  <div className="text-lg font-bold text-red-700">
                    {registrations.filter(reg => reg.status === 'rejected').length}
                  </div>
                  <div className="text-xs text-red-600">Rejected</div>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Popular Courses</h4>
                <div className="space-y-2">
                  {summerCourses
                    .slice(0, 3)
                    .map((course) => (
                      <div key={course.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                        <div>
                          <div className="font-medium">{course.name}</div>
                          <div className="text-xs text-gray-500">{course.department}</div>
                        </div>
                        <div className="text-sm font-medium">
                          {course.currentStudents}/{course.maxStudents}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
              
              <div className="text-center mt-2">
                <Button asChild variant="outline">
                  <Link to="/reports">View Full Reports</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Registration Trends</CardTitle>
            <CardDescription>Summer course registration activity</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <RechartsTooltip />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#3b95ff"
                    fill="#3b95ff"
                    fillOpacity={0.2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back, {currentUser.name}!
        </p>
      </div>

      {currentUser.role === 'student' && renderStudentDashboard()}
      {currentUser.role === 'faculty' && renderFacultyDashboard()}
      {currentUser.role === 'admin' && renderAdminDashboard()}
    </div>
  );
};

export default Dashboard;
