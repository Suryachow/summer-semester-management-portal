import React, { useEffect, useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { 
  UserCircle2, 
  Mail, 
  Calendar, 
  BookOpen, 
  Building2,
  Clock
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useUsers } from '@/context/UserContext';
import { User } from '@/types';

interface CourseProgress {
  id: string;
  code: string;
  name: string;
  progress: number;
  grade?: string;
}

const getStudentData = (studentId: string) => {
  if (studentId === '1') {
    return {
      enrolledCourses: [
        { id: '1', code: 'CS301', name: 'Database Management Systems', progress: 85, grade: 'A' },
        { id: '2', code: 'EE205', name: 'Digital Electronics', progress: 72, grade: 'B+' },
        { id: '3', code: 'ME102', name: 'Engineering Mechanics', progress: 65 },
        { id: '4', code: 'CS401', name: 'Machine Learning', progress: 45 },
      ],
      backlogCourses: [
        { id: '5', code: 'CS210', name: 'Data Structures', progress: 0 },
        { id: '6', code: 'MA201', name: 'Discrete Mathematics', progress: 30 },
      ],
      cgpa: 3.75
    };
  } else if (studentId === '4') {
    return {
      enrolledCourses: [
        { id: '1', code: 'EE301', name: 'Circuit Theory', progress: 90, grade: 'A+' },
        { id: '2', code: 'EE305', name: 'Power Systems', progress: 85, grade: 'A' },
        { id: '3', code: 'CS102', name: 'Programming Fundamentals', progress: 70 },
      ],
      backlogCourses: [
        { id: '5', code: 'MA101', name: 'Calculus', progress: 20 },
      ],
      cgpa: 3.9
    };
  } else {
    return {
      enrolledCourses: [
        { id: '1', code: 'CS101', name: 'Introduction to Programming', progress: 60 },
        { id: '2', code: 'MA101', name: 'Calculus I', progress: 55 },
      ],
      backlogCourses: [
        { id: '5', code: 'PHY101', name: 'Physics I', progress: 15 },
      ],
      cgpa: 3.0
    };
  }
};

const getFacultyData = (facultyId: string) => {
  if (facultyId === '2') {
    return {
      teachingCourses: [
        { id: '1', code: 'CS301', name: 'Database Management Systems', students: 45, department: 'Computer Science' },
        { id: '2', code: 'CS401', name: 'Machine Learning', students: 38, department: 'Computer Science' },
      ]
    };
  } else if (facultyId === '6') {
    return {
      teachingCourses: [
        { id: '1', code: 'CS101', name: 'Introduction to Programming', students: 60, department: 'Computer Science' },
        { id: '2', code: 'CS201', name: 'Data Structures', students: 42, department: 'Computer Science' },
      ]
    };
  } else {
    return {
      teachingCourses: [
        { id: '1', code: 'EE201', name: 'Basic Electronics', students: 35, department: 'Electrical Engineering' },
        { id: '2', code: 'EE301', name: 'Electric Machines', students: 28, department: 'Electrical Engineering' },
      ]
    };
  }
};

const StudentProfileContent = ({ user }: { user: User }) => {
  const [studentData, setStudentData] = useState<{
    enrolledCourses: CourseProgress[],
    backlogCourses: CourseProgress[],
    cgpa: number
  }>({
    enrolledCourses: [],
    backlogCourses: [],
    cgpa: 0
  });
  
  useEffect(() => {
    if (user.id) {
      setStudentData(getStudentData(user.id));
    }
  }, [user.id]);
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">CGPA</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{user.cgpa || studentData.cgpa || "3.0"}</div>
            <p className="text-muted-foreground text-sm">Current academic standing: Excellent</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Enrolled Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{studentData.enrolledCourses.length}</div>
            <p className="text-muted-foreground text-sm">Currently active courses</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Backlog Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{studentData.backlogCourses.length}</div>
            <p className="text-muted-foreground text-sm">Courses to be completed</p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="enrolled">
        <TabsList className="mb-4">
          <TabsTrigger value="enrolled">Enrolled Courses</TabsTrigger>
          <TabsTrigger value="backlogs">Backlog Courses</TabsTrigger>
        </TabsList>
        
        <TabsContent value="enrolled">
          <Card>
            <CardHeader>
              <CardTitle>Current Semester Courses</CardTitle>
              <CardDescription>Your progress in enrolled courses</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course Code</TableHead>
                    <TableHead>Course Name</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Grade</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {studentData.enrolledCourses.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground">No courses enrolled</TableCell>
                    </TableRow>
                  ) : (
                    studentData.enrolledCourses.map(course => (
                      <TableRow key={course.id}>
                        <TableCell className="font-medium">{course.code}</TableCell>
                        <TableCell>{course.name}</TableCell>
                        <TableCell>
                          <div className="w-full flex items-center gap-2">
                            <Progress value={course.progress} className="h-2 flex-1" />
                            <span className="text-sm font-medium">{course.progress}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {course.grade ? (
                            <Badge variant="outline" className="font-medium">
                              {course.grade}
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-muted-foreground">
                              In Progress
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="backlogs">
          <Card>
            <CardHeader>
              <CardTitle>Backlog Courses</CardTitle>
              <CardDescription>Courses that need to be completed</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course Code</TableHead>
                    <TableHead>Course Name</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {studentData.backlogCourses.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground">No backlog courses</TableCell>
                    </TableRow>
                  ) : (
                    studentData.backlogCourses.map(course => (
                      <TableRow key={course.id}>
                        <TableCell className="font-medium">{course.code}</TableCell>
                        <TableCell>{course.name}</TableCell>
                        <TableCell>
                          <div className="w-full flex items-center gap-2">
                            <Progress value={course.progress} className="h-2 flex-1" />
                            <span className="text-sm font-medium">{course.progress}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={course.progress > 0 ? "outline" : "secondary"} className="font-medium">
                            {course.progress > 0 ? "In Progress" : "Not Started"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
};

const FacultyProfileContent = ({ user }: { user: User }) => {
  const [facultyData, setFacultyData] = useState<{
    teachingCourses: {
      id: string;
      code: string;
      name: string;
      students: number;
      department: string;
    }[]
  }>({
    teachingCourses: []
  });
  
  useEffect(() => {
    if (user.id) {
      setFacultyData(getFacultyData(user.id));
    }
  }, [user.id]);
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Teaching Load</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{facultyData.teachingCourses.length} Courses</div>
            <p className="text-muted-foreground text-sm">Current semester</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {facultyData.teachingCourses.reduce((total, course) => total + course.students, 0)}
            </div>
            <p className="text-muted-foreground text-sm">Total students enrolled</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Department</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{user.department || "Computer Science"}</div>
            <p className="text-muted-foreground text-sm">Faculty member since {user.joinedDate || "2019"}</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Current Teaching Assignments</CardTitle>
          <CardDescription>Courses you are teaching this semester</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Course Code</TableHead>
                <TableHead>Course Name</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Students</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {facultyData.teachingCourses.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground">No teaching assignments</TableCell>
                </TableRow>
              ) : (
                facultyData.teachingCourses.map(course => (
                  <TableRow key={course.id}>
                    <TableCell className="font-medium">{course.code}</TableCell>
                    <TableCell>{course.name}</TableCell>
                    <TableCell>{course.department}</TableCell>
                    <TableCell>{course.students}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">View Details</Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
};

const AdminProfileContent = ({ user }: { user: User }) => {
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Users</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <Users2 className="h-10 w-10 text-primary" />
            <div>
              <div className="text-3xl font-bold">152</div>
              <p className="text-muted-foreground text-sm">Total system users</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Courses</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <BookOpen className="h-10 w-10 text-primary" />
            <div>
              <div className="text-3xl font-bold">42</div>
              <p className="text-muted-foreground text-sm">Active courses</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Departments</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <Building2 className="h-10 w-10 text-primary" />
            <div>
              <div className="text-3xl font-bold">8</div>
              <p className="text-muted-foreground text-sm">Academic departments</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Reports</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <FileText className="h-10 w-10 text-primary" />
            <div>
              <div className="text-3xl font-bold">24</div>
              <p className="text-muted-foreground text-sm">Generated reports</p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>System Activity</CardTitle>
          <CardDescription>Recent administrative activities</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Activity</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Timestamp</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>Created new user account</TableCell>
                <TableCell>admin@example.com</TableCell>
                <TableCell>Today, 10:30 AM</TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">View Details</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Updated course schedule</TableCell>
                <TableCell>admin@example.com</TableCell>
                <TableCell>Yesterday, 2:15 PM</TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">View Details</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Generated semester report</TableCell>
                <TableCell>admin@example.com</TableCell>
                <TableCell>Jun 15, 9:00 AM</TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">View Details</Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
};

const Profile = () => {
  const { currentUser } = useAuth();
  const { getUserById } = useUsers();
  
  const defaultUser: User = { 
    id: 'guest', 
    name: 'Guest User', 
    email: '', 
    role: 'student',
    status: 'Active',
    lastActive: new Date().toISOString().split('T')[0]
  };
  
  const user = currentUser || defaultUser;
  
  const userDetails = user.id ? getUserById(user.id) : null;
  
  const combinedUserData: User = {
    ...user,
    ...(userDetails || {}),
  };
  
  const renderRoleSpecificContent = () => {
    switch (user.role) {
      case 'student':
        return <StudentProfileContent user={combinedUserData} />;
      case 'faculty':
        return <FacultyProfileContent user={combinedUserData} />;
      case 'admin':
        return <AdminProfileContent user={combinedUserData} />;
      default:
        return <p>No profile data available</p>;
    }
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">My Profile</h1>
      
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
            {user.profileImage ? (
              <img 
                src={user.profileImage} 
                alt={user.name} 
                className="w-24 h-24 rounded-full object-cover"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
                <UserCircle2 className="h-16 w-16 text-primary" />
              </div>
            )}
            
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-2xl font-bold">{combinedUserData.name}</h2>
              <p className="text-muted-foreground">{combinedUserData.role.charAt(0).toUpperCase() + combinedUserData.role.slice(1)}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{combinedUserData.email}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Joined {combinedUserData.joinedDate || "N/A"}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span>{combinedUserData.department || "N/A"}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Last active: {combinedUserData.lastActive || "N/A"}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {renderRoleSpecificContent()}
    </div>
  );
};

export default Profile;
