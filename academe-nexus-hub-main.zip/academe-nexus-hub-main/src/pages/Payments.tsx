
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";
import { Search, Download, CreditCard, Calendar, FileText, CheckCircle2, Download as DownloadIcon } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

// Payment type definition
interface Payment {
  id: string;
  studentName: string;
  courseCode: string;
  courseName: string;
  amount: number;
  date: string;
  method: "Credit Card" | "Net Banking" | "UPI" | "Bank Transfer";
  status: "Completed" | "Pending" | "Failed";
  receiptNo: string;
}

const Payments = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Mock payment data
  const [payments, setPayments] = useState<Payment[]>([
    { 
      id: '1', 
      studentName: 'John Student', 
      courseCode: 'CS301', 
      courseName: 'Database Management Systems', 
      amount: 12500, 
      date: '2023-06-15', 
      method: 'Credit Card', 
      status: 'Completed', 
      receiptNo: 'REC001234' 
    },
    { 
      id: '2', 
      studentName: 'Priya Sharma', 
      courseCode: 'CS302', 
      courseName: 'Operating Systems', 
      amount: 12500, 
      date: '2023-06-10', 
      method: 'UPI', 
      status: 'Completed', 
      receiptNo: 'REC001235' 
    },
    { 
      id: '3', 
      studentName: 'Rahul Verma', 
      courseCode: 'MA201', 
      courseName: 'Probability & Statistics', 
      amount: 10000, 
      date: '2023-06-05', 
      method: 'Net Banking', 
      status: 'Pending', 
      receiptNo: 'REC001236' 
    },
    { 
      id: '4', 
      studentName: 'Ananya Patel', 
      courseCode: 'EC202', 
      courseName: 'Digital Electronics', 
      amount: 15000, 
      date: '2023-05-20', 
      method: 'Credit Card', 
      status: 'Failed', 
      receiptNo: 'REC001237' 
    },
    { 
      id: '5', 
      studentName: 'John Student', 
      courseCode: 'PH101', 
      courseName: 'Engineering Physics', 
      amount: 8000, 
      date: '2023-06-18', 
      method: 'Bank Transfer', 
      status: 'Completed', 
      receiptNo: 'REC001238' 
    },
  ]);
  
  // Filter payments based on search query and status filter
  const filteredPayments = payments
    .filter(payment => 
      payment.studentName.toLowerCase().includes(searchQuery.toLowerCase()) || 
      payment.courseName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.receiptNo.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .filter(payment => statusFilter === 'all' || payment.status.toLowerCase() === statusFilter.toLowerCase());
  
  // Handle new payment
  const handleMakePayment = (formData: FormData) => {
    const courseName = formData.get('course') as string;
    const amount = formData.get('amount') as string;
    const method = formData.get('method') as "Credit Card" | "Net Banking" | "UPI" | "Bank Transfer";
    
    if (!courseName || !amount || !method) {
      toast({
        title: "Error processing payment",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    const newPayment: Payment = {
      id: (payments.length + 1).toString(),
      studentName: 'Current Student',
      courseCode: 'CS' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
      courseName,
      amount: parseFloat(amount),
      date: new Date().toISOString().split('T')[0],
      method,
      status: 'Completed',
      receiptNo: 'REC' + Math.floor(Math.random() * 1000000).toString().padStart(6, '0')
    };
    
    setPayments(prev => [...prev, newPayment]);
    toast({
      title: "Payment successful",
      description: `Your payment of ₹${amount} for ${courseName} has been processed.`,
    });
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-brand-800">Payments</h1>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-brand-600 hover:bg-brand-700 text-white">
              <CreditCard className="h-4 w-4 mr-2" />
              Make Payment
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Make a Payment</DialogTitle>
              <DialogDescription>
                Enter the payment details below.
              </DialogDescription>
            </DialogHeader>
            
            <form action="" className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              handleMakePayment(formData);
              e.currentTarget.reset();
              // Using DialogClose component instead of directly clicking the element
            }}>
              <div className="space-y-2">
                <label htmlFor="course" className="text-sm font-medium">Select Course</label>
                <Select name="course" defaultValue="Database Management Systems">
                  <SelectTrigger>
                    <SelectValue placeholder="Select a course" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Database Management Systems">Database Management Systems</SelectItem>
                    <SelectItem value="Operating Systems">Operating Systems</SelectItem>
                    <SelectItem value="Computer Networks">Computer Networks</SelectItem>
                    <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                    <SelectItem value="Engineering Physics">Engineering Physics</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="amount" className="text-sm font-medium">Amount (₹)</label>
                <Input id="amount" name="amount" type="number" defaultValue="12500" required />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="method" className="text-sm font-medium">Payment Method</label>
                <Select name="method" defaultValue="Credit Card">
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Credit Card">Credit Card</SelectItem>
                    <SelectItem value="Net Banking">Net Banking</SelectItem>
                    <SelectItem value="UPI">UPI</SelectItem>
                    <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="submit" className="bg-brand-600 hover:bg-brand-700 text-white">
                    Complete Payment
                  </Button>
                </DialogClose>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
          <CardDescription>
            View and manage all financial transactions
          </CardDescription>
          
          <div className="flex flex-col sm:flex-row gap-4 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search payments..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableCaption>A list of all your payment transactions</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Receipt No.</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPayments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-6 text-muted-foreground">
                    No payments found matching your search criteria
                  </TableCell>
                </TableRow>
              ) : (
                filteredPayments.map(payment => (
                  <TableRow key={payment.id}>
                    <TableCell className="font-medium">{payment.receiptNo}</TableCell>
                    <TableCell>{payment.courseName}</TableCell>
                    <TableCell>{payment.date}</TableCell>
                    <TableCell>{payment.method}</TableCell>
                    <TableCell>₹{payment.amount.toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge className={`
                        ${payment.status === 'Completed' ? 'bg-green-100 text-green-800' : ''}
                        ${payment.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                        ${payment.status === 'Failed' ? 'bg-red-100 text-red-800' : ''}
                      `}>
                        {payment.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" className="text-brand-600 hover:text-brand-700">
                        <DownloadIcon className="h-4 w-4 mr-1" />
                        Receipt
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div>
            <span className="text-sm text-muted-foreground">Total Paid: </span>
            <span className="font-medium">₹{filteredPayments
              .filter(p => p.status === 'Completed')
              .reduce((sum, p) => sum + p.amount, 0)
              .toLocaleString()}</span>
          </div>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export All
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Payments;
