
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import ForgotPasswordForm from '@/components/auth/ForgotPasswordForm';
import OtpVerificationForm from '@/components/auth/OtpVerificationForm';
import ResetPasswordForm from '@/components/auth/ResetPasswordForm';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

const Auth: React.FC = () => {
  const [authState, setAuthState] = useState<'login' | 'register' | 'forgot-password' | 'otp-verification' | 'reset-password'>('login');
  const [email, setEmail] = useState('');

  const handleForgotPassword = (email: string) => {
    setEmail(email);
    setAuthState('otp-verification');
  };

  const handleOtpVerification = () => {
    setAuthState('reset-password');
  };

  const handleResetSuccess = () => {
    setAuthState('login');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Left side with university image */}
      <div className="w-full md:w-1/2 bg-brand-800 flex items-center justify-center relative overflow-hidden">
        <div className="relative z-10 p-8 text-center">
          <img 
            src="/lovable-uploads/31072c56-aa73-4aa8-815e-345da39affb7.png" 
            alt="Vignan University" 
            className="max-w-full h-auto mb-6 mx-auto rounded-lg shadow-lg"
          />
          <h1 className="text-3xl font-bold text-white mb-2">Vignan University Portal</h1>
          <p className="text-brand-200 text-lg mb-6">
            Summer Courses & Backlog Management System
          </p>
          <div className="space-y-4 text-left bg-white/10 backdrop-blur-sm p-6 rounded-lg">
            <h2 className="text-xl font-semibold text-white">Portal Features:</h2>
            <ul className="space-y-2 text-white">
              <li className="flex items-center">
                <span className="bg-brand-500 rounded-full w-2 h-2 mr-2"></span>
                Course registration & management
              </li>
              <li className="flex items-center">
                <span className="bg-brand-500 rounded-full w-2 h-2 mr-2"></span>
                Backlog tracking & clearing
              </li>
              <li className="flex items-center">
                <span className="bg-brand-500 rounded-full w-2 h-2 mr-2"></span>
                Real-time notifications
              </li>
              <li className="flex items-center">
                <span className="bg-brand-500 rounded-full w-2 h-2 mr-2"></span>
                Secure payment processing
              </li>
              <li className="flex items-center">
                <span className="bg-brand-500 rounded-full w-2 h-2 mr-2"></span>
                Role-based dashboards
              </li>
            </ul>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-brand-900/80 to-brand-700/80 z-0"></div>
      </div>
      
      {/* Right side with auth forms */}
      <div className="w-full md:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <Link to="/" className="inline-flex items-center text-brand-600 hover:text-brand-800 transition-colors">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back to Home
            </Link>
          </div>
          
          {authState === 'login' && (
            <Card className="border-brand-200 shadow-lg">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold text-center">Sign In</CardTitle>
                <CardDescription className="text-center">
                  Enter your credentials to access your account
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="student" className="mb-6">
                  <TabsList className="grid grid-cols-3 w-full">
                    <TabsTrigger value="student">Student</TabsTrigger>
                    <TabsTrigger value="faculty">Faculty</TabsTrigger>
                    <TabsTrigger value="admin">Admin</TabsTrigger>
                  </TabsList>
                  <TabsContent value="student">
                    <LoginForm 
                      onSwitchToRegister={() => setAuthState('register')} 
                      onSwitchToForgotPassword={() => setAuthState('forgot-password')} 
                    />
                  </TabsContent>
                  <TabsContent value="faculty">
                    <LoginForm 
                      onSwitchToRegister={() => setAuthState('register')} 
                      onSwitchToForgotPassword={() => setAuthState('forgot-password')} 
                    />
                  </TabsContent>
                  <TabsContent value="admin">
                    <LoginForm 
                      onSwitchToRegister={() => setAuthState('register')} 
                      onSwitchToForgotPassword={() => setAuthState('forgot-password')} 
                    />
                  </TabsContent>
                </Tabs>
                
                <div className="text-center mt-4">
                  <p className="text-sm text-muted-foreground">
                    Don't have an account?{" "}
                    <button 
                      onClick={() => setAuthState('register')}
                      className="text-brand-600 hover:text-brand-800 font-medium underline-offset-4 hover:underline"
                    >
                      Register
                    </button>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
          
          {authState === 'register' && (
            <Card className="border-brand-200 shadow-lg">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold text-center">Create an Account</CardTitle>
                <CardDescription className="text-center">
                  Enter your details to register
                </CardDescription>
              </CardHeader>
              <CardContent>
                <RegisterForm onSwitchToLogin={() => setAuthState('login')} />
                
                <div className="text-center mt-4">
                  <p className="text-sm text-muted-foreground">
                    Already have an account?{" "}
                    <button 
                      onClick={() => setAuthState('login')}
                      className="text-brand-600 hover:text-brand-800 font-medium underline-offset-4 hover:underline"
                    >
                      Sign In
                    </button>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
          
          {authState === 'forgot-password' && (
            <Card className="border-brand-200 shadow-lg">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold text-center">Forgot Password</CardTitle>
                <CardDescription className="text-center">
                  Enter your email to receive a verification code
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ForgotPasswordForm 
                  onSwitchToLogin={() => setAuthState('login')}
                  onSwitchToOtpVerification={handleForgotPassword}
                />
                
                <div className="text-center mt-4">
                  <p className="text-sm text-muted-foreground">
                    <button 
                      onClick={() => setAuthState('login')}
                      className="text-brand-600 hover:text-brand-800 font-medium underline-offset-4 hover:underline"
                    >
                      Back to Sign In
                    </button>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
          
          {authState === 'otp-verification' && (
            <Card className="border-brand-200 shadow-lg">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold text-center">Verify OTP</CardTitle>
                <CardDescription className="text-center">
                  Enter the verification code sent to {email}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <OtpVerificationForm 
                  email={email}
                  onSwitchToResetPassword={handleOtpVerification}
                  onSwitchToLogin={() => setAuthState('login')}
                />
                
                <div className="text-center mt-4">
                  <p className="text-sm text-muted-foreground">
                    <button 
                      onClick={() => setAuthState('forgot-password')}
                      className="text-brand-600 hover:text-brand-800 font-medium underline-offset-4 hover:underline"
                    >
                      Back to Forgot Password
                    </button>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
          
          {authState === 'reset-password' && (
            <Card className="border-brand-200 shadow-lg">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold text-center">Reset Password</CardTitle>
                <CardDescription className="text-center">
                  Create a new password for your account
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResetPasswordForm onSwitchToLogin={handleResetSuccess} />
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;
