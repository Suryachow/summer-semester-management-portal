
import React from 'react';
import { Notification } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Check, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';

interface NotificationItemProps {
  notification: Notification;
  onMarkAsRead: (id: string) => void;
  onDelete: (id: string) => void;
}

const NotificationItem: React.FC<NotificationItemProps> = ({
  notification,
  onMarkAsRead,
  onDelete,
}) => {
  const getNotificationTypeIcon = (type: Notification['type']) => {
    switch (type) {
      case 'registration':
        return <span className="text-blue-500">📝</span>;
      case 'payment':
        return <span className="text-green-500">💰</span>;
      case 'approval':
        return <span className="text-purple-500">✅</span>;
      default:
        return <span className="text-gray-500">📢</span>;
    }
  };

  return (
    <div className={`p-3 border-b last:border-0 ${!notification.isRead ? 'bg-blue-50' : ''}`}>
      <div className="flex items-start">
        <div className="flex-shrink-0 mr-3">{getNotificationTypeIcon(notification.type)}</div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h4 className="text-sm font-medium">{notification.title}</h4>
            <span className="text-xs text-gray-500">
              {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
            </span>
          </div>
          <p className="text-sm mt-1 text-gray-600">{notification.message}</p>
          {notification.link && (
            <Link to={notification.link} className="text-xs text-blue-600 hover:underline mt-2 inline-block">
              View details
            </Link>
          )}
        </div>
      </div>
      <div className="flex justify-end space-x-2 mt-2">
        {!notification.isRead && (
          <Button
            size="sm"
            variant="ghost"
            className="h-8 px-2 text-xs"
            onClick={() => onMarkAsRead(notification.id)}
          >
            <Check className="h-3 w-3 mr-1" /> Mark as read
          </Button>
        )}
        <Button
          size="sm"
          variant="ghost"
          className="h-8 px-2 text-xs text-red-500 hover:text-red-700"
          onClick={() => onDelete(notification.id)}
        >
          <Trash2 className="h-3 w-3 mr-1" /> Delete
        </Button>
      </div>
    </div>
  );
};

export default NotificationItem;
