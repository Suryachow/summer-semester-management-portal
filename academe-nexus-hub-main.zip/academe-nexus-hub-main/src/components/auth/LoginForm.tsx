
import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserRole } from '@/types';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { LockKeyhole, Mail, UserCircle2 } from 'lucide-react';

interface LoginFormProps {
  onSwitchToRegister: () => void;
  onSwitchToForgotPassword: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ 
  onSwitchToRegister, 
  onSwitchToForgotPassword 
}) => {
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    const success = await login(email, password);
    if (success) {
      navigate('/dashboard');
    }
  };

  // Demo login shortcuts
  const handleDemoLogin = async (role: UserRole) => {
    let demoEmail = '';
    let demoPassword = 'password123'; // Not actually used in the mock auth
    
    switch (role) {
      case 'student':
        demoEmail = 'student@example.com';
        break;
      case 'faculty':
        demoEmail = 'faculty@example.com';
        break;
      case 'admin':
        demoEmail = 'admin@example.com';
        break;
    }
    
    const success = await login(demoEmail, demoPassword);
    if (success) {
      navigate('/dashboard');
    }
  };

  return (
    <Card className="w-full max-w-md border-brand-200 shadow-lg">
      <CardHeader className="space-y-1 bg-gradient-to-r from-brand-50 to-brand-100 rounded-t-lg">
        <CardTitle className="text-2xl font-bold text-center text-brand-800">Sign In</CardTitle>
        <CardDescription className="text-center text-brand-600">
          Access your Vignan University account
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-brand-700 flex items-center gap-2">
              <Mail className="h-4 w-4" /> Email
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="name@vignanunicersity.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-brand-200 focus:ring-brand-500 focus:border-brand-500"
              required
            />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="password" className="text-brand-700 flex items-center gap-2">
                <LockKeyhole className="h-4 w-4" /> Password
              </Label>
              <button
                type="button"
                onClick={onSwitchToForgotPassword}
                className="text-sm text-brand-600 hover:text-brand-800 transition-colors"
              >
                Forgot password?
              </button>
            </div>
            <Input
              id="password"
              type="password"
              value={password}
              className="border-brand-200 focus:ring-brand-500 focus:border-brand-500"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button 
            type="submit" 
            className="w-full bg-brand-600 hover:bg-brand-700 text-white" 
            disabled={isLoading}
          >
            {isLoading ? 'Signing in...' : 'Sign In'}
          </Button>
        </form>
        
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-brand-200" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-brand-500">
                Quick Demo Access
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-4">
            <Button 
              variant="outline" 
              onClick={() => handleDemoLogin('student')}
              className="text-xs h-9 border-brand-200 text-brand-700 hover:bg-brand-50"
            >
              Student
            </Button>
            <Button 
              variant="outline" 
              onClick={() => handleDemoLogin('faculty')}
              className="text-xs h-9 border-brand-200 text-brand-700 hover:bg-brand-50"
            >
              Faculty
            </Button>
            <Button 
              variant="outline" 
              onClick={() => handleDemoLogin('admin')}
              className="text-xs h-9 border-brand-200 text-brand-700 hover:bg-brand-50"
            >
              Admin
            </Button>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col bg-gradient-to-r from-brand-50 to-brand-100 rounded-b-lg">
        <div className="text-sm text-center text-brand-700">
          New to Vignan University?{' '}
          <button
            type="button"
            onClick={onSwitchToRegister}
            className="text-brand-600 font-medium hover:text-brand-800 transition-colors"
          >
            Create Account
          </button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default LoginForm;
