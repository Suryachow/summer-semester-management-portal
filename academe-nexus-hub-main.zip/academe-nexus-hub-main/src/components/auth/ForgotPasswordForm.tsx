
import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, Mail, SendHorizontal } from 'lucide-react';

interface ForgotPasswordFormProps {
  onSwitchToLogin: () => void;
  onSwitchToOtpVerification: (email: string) => void;
}

const ForgotPasswordForm: React.FC<ForgotPasswordFormProps> = ({ 
  onSwitchToLogin, 
  onSwitchToOtpVerification 
}) => {
  const { forgotPassword, isLoading } = useAuth();
  const [email, setEmail] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error('Please enter your email address');
      return;
    }
    
    const success = await forgotPassword(email);
    if (success) {
      onSwitchToOtpVerification(email);
    }
  };

  return (
    <Card className="w-full max-w-md border-brand-200 shadow-lg">
      <CardHeader className="space-y-1 bg-gradient-to-r from-brand-50 to-brand-100 rounded-t-lg">
        <CardTitle className="text-2xl font-bold text-center text-brand-800">Reset Password</CardTitle>
        <CardDescription className="text-center text-brand-600">
          Enter your email address and we'll send you an OTP to reset your password
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-brand-700 flex items-center gap-2">
              <Mail className="h-4 w-4" /> Email Address
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="name@vignanunicersity.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-brand-200 focus:ring-brand-500 focus:border-brand-500"
              required
            />
          </div>
          <Button 
            type="submit" 
            className="w-full bg-brand-600 hover:bg-brand-700 text-white flex items-center justify-center gap-2" 
            disabled={isLoading}
          >
            <SendHorizontal className="h-4 w-4" />
            {isLoading ? 'Sending...' : 'Send Reset Instructions'}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col bg-gradient-to-r from-brand-50 to-brand-100 rounded-b-lg">
        <button
          type="button"
          onClick={onSwitchToLogin}
          className="flex items-center justify-center gap-2 text-brand-600 hover:text-brand-800 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" /> Back to login
        </button>
      </CardFooter>
    </Card>
  );
};

export default ForgotPasswordForm;
