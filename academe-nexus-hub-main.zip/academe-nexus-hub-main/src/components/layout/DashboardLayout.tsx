
import React, { useState } from 'react';
import { useNavigate, Link, Outlet } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useNotifications } from '@/context/NotificationContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { 
  Bell, 
  BookOpen, 
  ChevronDown,
  ClipboardList,
  FileText,
  Home,
  LayoutDashboard, 
  LogOut, 
  Menu, 
  Settings, 
  User, 
  Users, 
  X, 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import NotificationList from '@/components/notifications/NotificationList';
import { UserRole } from '@/types';

const DashboardLayout: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { unreadCount } = useNotifications();
  const navigate = useNavigate();
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  
  if (!currentUser) {
    navigate('/auth');
    return null;
  }

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleNotifications = () => {
    setIsNotificationsOpen(!isNotificationsOpen);
  };

  const getNavItems = (role: UserRole) => {
    const baseItems = [
      { 
        label: 'Dashboard', 
        icon: <LayoutDashboard className="h-5 w-5" />, 
        link: '/dashboard' 
      },
      { 
        label: 'Courses', 
        icon: <BookOpen className="h-5 w-5" />, 
        link: '/courses' 
      },
    ];
    
    if (role === 'student') {
      return [
        ...baseItems,
        { 
          label: 'My Registrations', 
          icon: <ClipboardList className="h-5 w-5" />, 
          link: '/registrations' 
        },
        { 
          label: 'Backlogs', 
          icon: <FileText className="h-5 w-5" />, 
          link: '/backlogs' 
        },
      ];
    } else if (role === 'faculty') {
      return [
        ...baseItems,
        { 
          label: 'Approve Registrations', 
          icon: <ClipboardList className="h-5 w-5" />, 
          link: '/registrations' 
        },
        { 
          label: 'Students', 
          icon: <Users className="h-5 w-5" />, 
          link: '/students' 
        },
        { 
          label: 'Reports', 
          icon: <FileText className="h-5 w-5" />, 
          link: '/reports' 
        },
      ];
    } else if (role === 'admin') {
      return [
        ...baseItems,
        { 
          label: 'Registrations', 
          icon: <ClipboardList className="h-5 w-5" />, 
          link: '/registrations' 
        },
        { 
          label: 'Students', 
          icon: <Users className="h-5 w-5" />, 
          link: '/students' 
        },
        { 
          label: 'Backlogs', 
          icon: <FileText className="h-5 w-5" />, 
          link: '/backlogs' 
        },
        { 
          label: 'User Management', 
          icon: <Users className="h-5 w-5" />, 
          link: '/users' 
        },
        { 
          label: 'Reports', 
          icon: <FileText className="h-5 w-5" />, 
          link: '/reports' 
        },
      ];
    }
    
    return baseItems;
  };

  const navItems = getNavItems(currentUser.role);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleSidebar}
              className="p-2 rounded-md hover:bg-gray-100 lg:hidden"
              aria-label="Toggle sidebar"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-xl text-blue-600">Vignan University Portal</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative"
                    onClick={toggleNotifications}
                  >
                    <Bell className="h-5 w-5" />
                    {unreadCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 px-1.5 py-0.5 text-xs">
                        {unreadCount}
                      </Badge>
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Notifications</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={currentUser.profileImage} alt={currentUser.name} />
                    <AvatarFallback>{currentUser.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline-block text-sm font-medium">
                    {currentUser.name}
                  </span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col">
                    <span>{currentUser.name}</span>
                    <span className="text-xs text-gray-500">{currentUser.email}</span>
                    <span className="mt-1">
                      <Badge variant="outline" className={`
                        role-badge
                        ${currentUser.role === 'student' ? 'role-badge-student' : ''}
                        ${currentUser.role === 'faculty' ? 'role-badge-faculty' : ''}
                        ${currentUser.role === 'admin' ? 'role-badge-admin' : ''}
                      `}>
                        {currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}
                      </Badge>
                    </span>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <Link to="/profile" className="flex items-center w-full">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <Link to="/settings" className="flex items-center w-full">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex">
        <aside className={`
          bg-white border-r border-gray-200 fixed inset-y-0 z-20
          transition-transform duration-300 ease-in-out
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          lg:translate-x-0 lg:static lg:flex-shrink-0 mt-16 h-[calc(100vh-4rem)]
          ${isSidebarOpen ? 'w-64' : 'w-0'}
          lg:w-64
        `}>
          <div className="h-full flex flex-col overflow-y-auto">
            <nav className="flex-1 px-4 py-4 space-y-1">
              {navItems.map((item, index) => (
                <Link
                  key={index}
                  to={item.link}
                  className="flex items-center px-3 py-2 text-sm rounded-md text-gray-700 hover:bg-gray-100"
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </Link>
              ))}
            </nav>
            
            <div className="p-4 border-t border-gray-200">
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </aside>

        <div className={`
          fixed inset-y-0 right-0 z-30 w-72 bg-white border-l border-gray-200 transform transition-transform duration-300 ease-in-out
          ${isNotificationsOpen ? 'translate-x-0' : 'translate-x-full'}
          mt-16 h-[calc(100vh-4rem)]
        `}>
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold">Notifications</h2>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleNotifications}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <NotificationList />
        </div>

        <div className={`
          flex-1 overflow-auto p-6 transition-all duration-300 
          lg:ml-0 mt-0 h-[calc(100vh-4rem)]
        `}>
          <Outlet />
        </div>
      </div>

      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10 lg:hidden"
          onClick={toggleSidebar}
        />
      )}
      
      {isNotificationsOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20"
          onClick={toggleNotifications}
        />
      )}
    </div>
  );
};

export default DashboardLayout;
